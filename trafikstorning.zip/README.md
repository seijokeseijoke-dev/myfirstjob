# Störning på sträckan – installation på Galaxy A17

Webbapp (PWA). Den anropar Trafikverkets API direkt från telefonen, så den behöver bara
läggas på en webbadress med HTTPS. Gratis och enklast: GitHub Pages.

## 1. Lägg upp filerna (en gång, ca 10 min)
1. Skapa konto på github.com (om du saknar).
2. Nytt repository, t.ex. `trafikstorning`, välj **Public**.
3. "Add file" → "Upload files" → dra in alla filer ur zip-filen:
   `index.html, manifest.webmanifest, sw.js, icon-192.png, icon-512.png, icon-512-maskable.png`
4. Settings → Pages → Source: "Deploy from a branch", Branch: `main`, mapp `/ (root)` → Save.
5. Efter 1–2 minuter finns appen på `https://<ditt-användarnamn>.github.io/trafikstorning/`

## 2. Installera på telefonen
1. Öppna adressen i **Chrome** på Galaxy A17.
2. Meny (⋮) → **Lägg till på startskärmen** / **Installera app**.
3. Appen får egen ikon och öppnas i helskärm utan adressfält.

Uppdatering: ladda upp en ny `index.html` till GitHub; telefonen hämtar den nästa gång appen öppnas med nät.

## Hur filtreringen fungerar
- Orterna slås upp via OpenStreetMap (Nominatim).
- Sträckan = snabbaste bilväg enligt OSRM (OpenStreetMap), med vägnummer för varje delsträcka (t.ex. 158 → E45 → E6 → 162 → 171 → 174). Visas som "Via …" i appen.
- En störning tas med bara om den ligger högst 300 m från en del av rutten med samma vägnummer. Korsande vägar och parallella delar av samma väg (t.ex. E6.21 Lundbyleden när rutten går via E45) räknas bort och visas som "på korsande/parallella vägar".
- Har rutten inga vägnummer alls används avstånd ± 1 km från vägen.
- Svarar inte ruttjänsten inom 10 s används en rak korridor ± 15 km, och appen visar en varning om det.
- Hämtar bara händelser i rutor längs vägen (inte hela Sverige, som är ca 14 MB).
- Typer: olyckor, hinder, kö/avstängt/haveri/djur/träd m.fl., vägarbeten.
- Vägarbeten: standard bara "Mycket stor påverkan" (kan ändras i appen).
- Bort: "Trafikmeddelande / Vägen avstängd" utan egen orsak; när det hör till ett vägarbete visas det som en liten markering "avstängd" i vägarbetets cell.
- Bort: körfältsavstängning, hastighets-/viktbegränsning, omkörningsförbud, färjor.
- Bort: meddelanden utan vägnamn ("Unnamed road"), och som standard gator utan vägnummer.
- Tid: bara händelser som pågår någon gång mellan starttid och ankomsttid idag.
- Dubbletter: samma händelse-id, eller samma väg + typ + plats + tid, eller samma väg + samma text.
- Max 6 orsaker per väg; resten nås via "+N till".

## Kända begränsningar
- Ruttjänsten är OSRM:s publika demoserver: gratis och utan nyckel, men utan driftgaranti. Alternativ vid behov: OpenRouteService (gratis nyckel).
- Rutten är den OSRM anser snabbast. Den kan skilja sig från den väg du själv väljer.
- Vägnumren kommer från OpenStreetMap. Saknas numret på en bit väg där räknas störningar på den biten bort.
- En störning på en avfart eller korsande väg precis vid din väg, t.ex. en avstängd påfart på väg 160, syns inte om den har det andra vägnumret.
- API-nyckeln ligger synlig i appens källkod. Det är normalt för Trafikverkets gratisnycklar, men byt nyckel om den skulle missbrukas.
- Fungerar även på iPhone (Safari → Dela → Lägg till på hemskärmen).
